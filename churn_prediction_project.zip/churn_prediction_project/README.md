# Customer Churn Prediction with Explainable AI

A 3rd-year CSE (Software / Data Science) project that predicts whether a
telecom customer is likely to churn (leave), and — more importantly —
**explains why**, using SHAP.

## Why this project stands out

Most "churn prediction" student projects stop at training a model and
reporting accuracy. This one goes further:

- Compares **3 models** properly (not just accuracy — precision, recall,
  F1, ROC-AUC, since churn data is imbalanced)
- Adds **SHAP explainability** so predictions aren't a black box
- Ships an **interactive Streamlit dashboard** you can actually demo live
- Clean, modular code — each pipeline step is its own script

## Project structure

```
churn_prediction_project/
├── data/
│   ├── telco_churn.csv            # raw data (generated or from Kaggle)
│   ├── telco_churn_clean.csv      # after cleaning
│   └── telco_churn_featured.csv   # after feature engineering (model-ready)
├── src/
│   ├── generate_sample_data.py    # STEP 1 helper: synthetic data for testing
│   ├── data_cleaning.py           # STEP 1: load + clean
│   ├── eda.py                     # STEP 2: exploratory analysis + plots
│   ├── feature_engineering.py     # STEP 3: new features + encoding
│   ├── train_models.py            # STEP 4: train + compare models
│   └── explainability.py          # STEP 5: SHAP explanations
├── outputs/
│   ├── plots/                     # all EDA + SHAP charts (PNG)
│   └── models/                    # saved best model + comparison table
├── app.py                         # STEP 6: Streamlit dashboard
├── requirements.txt
└── README.md
```

## Setup

```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## How to run the full pipeline

Run these **in order** from the project root:

```bash
# 1. Get data (synthetic, for testing — see "Using the real dataset" below)
python src/generate_sample_data.py

# 2. Clean it
python src/data_cleaning.py

# 3. Explore it (saves 6 plots to outputs/plots/)
python src/eda.py

# 4. Engineer features
python src/feature_engineering.py

# 5. Train + compare models (saves best model to outputs/models/)
python src/train_models.py

# 6. Generate SHAP explanations (saves 2 more plots to outputs/plots/)
python src/explainability.py

# 7. Launch the interactive dashboard
streamlit run app.py
```

## Using the real dataset (recommended before submission)

This repo ships with a **synthetic data generator** so you can test the
whole pipeline immediately without needing a Kaggle account. For your
actual submission, swap in the real dataset:

1. Download **Telco Customer Churn** from Kaggle:
   https://www.kaggle.com/datasets/blastchar/telco-customer-churn
2. Save the CSV as `data/telco_churn.csv` (same filename, same columns)
3. Skip step 1 (`generate_sample_data.py`) and just re-run steps 2–7 above

The rest of the pipeline works identically either way since column names match.

## Models compared

| Model | Notes |
|---|---|
| Logistic Regression | Fast, interpretable baseline |
| Random Forest | Handles non-linearity, feature importance built-in |
| XGBoost (or GradientBoosting if xgboost isn't installed) | Usually best raw performance |

The script automatically picks the model with the highest **ROC-AUC** and
saves it as the one the dashboard uses.

## Explainability (the standout feature)

`src/explainability.py` and the SHAP panel inside `app.py` show:
- **Summary plot** — which features drive churn overall across all customers
- **Waterfall plot** — for one specific customer, exactly which factors
  pushed their churn probability up or down (e.g. "month-to-month contract
  +12%", "long tenure −8%")

This turns "the model said 72%" into "the model said 72% *because* ..." —
which is exactly the kind of thing that impresses evaluators and interviewers.

## Suggested report/presentation structure

1. Problem statement — why churn prediction matters for telecom businesses
2. Dataset overview + EDA findings (use the 6 saved plots)
3. Feature engineering rationale
4. Model comparison table + why you picked the final model
5. SHAP explainability — 2-3 example customers with waterfall charts
6. Live demo of the Streamlit dashboard
7. Limitations + future work (e.g. try deep learning, add more data sources)

## Possible extensions (if you have extra time)

- Try SMOTE/class-weighting variations to handle imbalance differently
- Add a "what-if" feature to the dashboard (e.g. "if this customer switched
  to a 2-year contract, how much would their churn risk drop?")
- Deploy the Streamlit app for free on Streamlit Community Cloud and put
  the live link in your resume/README
