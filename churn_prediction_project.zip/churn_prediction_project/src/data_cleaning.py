"""
data_cleaning.py
----------------
STEP 1: Load the raw churn dataset and clean it.

What this does:
  1. Loads data/telco_churn.csv
  2. Fixes the TotalCharges column (some rows have blank strings " ")
  3. Drops customerID (not predictive, just an identifier)
  4. Encodes the target column Churn -> 0/1
  5. Saves a cleaned CSV to data/telco_churn_clean.csv

Usage:
    python src/data_cleaning.py
"""

import pandas as pd
import os

RAW_PATH = os.path.join("data", "telco_churn.csv")
CLEAN_PATH = os.path.join("data", "telco_churn_clean.csv")


def load_data(path=RAW_PATH):
    if not os.path.exists(path):
        raise FileNotFoundError(
            f"Couldn't find {path}. Either download the real Kaggle dataset "
            f"and save it there, or run: python src/generate_sample_data.py"
        )
    return pd.read_csv(path)


def clean_data(df):
    df = df.copy()

    # TotalCharges sometimes arrives as blank strings for brand-new customers
    df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce")
    missing_count = df["TotalCharges"].isna().sum()
    if missing_count > 0:
        # These are almost always tenure == 0 customers -> total charges should be 0
        df["TotalCharges"] = df["TotalCharges"].fillna(0)
        print(f"Fixed {missing_count} blank TotalCharges values (set to 0).")

    # Drop identifier column - not useful for modeling
    if "customerID" in df.columns:
        df = df.drop(columns=["customerID"])

    # Encode target variable
    df["Churn"] = df["Churn"].map({"Yes": 1, "No": 0})

    # Sanity checks
    assert df["Churn"].isna().sum() == 0, "Unexpected value in Churn column"
    n_dupes = df.duplicated().sum()
    if n_dupes > 0:
        df = df.drop_duplicates()
        print(f"Dropped {n_dupes} duplicate rows.")

    return df


def summarize(df):
    print("\n--- Dataset summary ---")
    print(f"Rows: {df.shape[0]}, Columns: {df.shape[1]}")
    print(f"Churn rate: {df['Churn'].mean():.2%}")
    print(f"Missing values remaining: {df.isna().sum().sum()}")
    print("\nColumn dtypes:")
    print(df.dtypes)


if __name__ == "__main__":
    raw_df = load_data()
    clean_df = clean_data(raw_df)
    summarize(clean_df)
    clean_df.to_csv(CLEAN_PATH, index=False)
    print(f"\nCleaned dataset saved to {CLEAN_PATH}")
