"""
feature_engineering.py
-----------------------
STEP 3: Create new features that help the model (and show YOUR understanding
of the data, not just the algorithm - evaluators love this part).

New features created:
  1. tenure_bucket        - New / 1yr / 2yr / Veteran groups
  2. avg_monthly_spend     - TotalCharges / tenure (handles tenure=0 safely)
  3. num_services          - how many add-on services the customer has
  4. has_internet_addons   - whether they have security/backup/protection/support
  5. is_high_value         - top 25% by MonthlyCharges

Also one-hot encodes all remaining categorical columns so the data is
model-ready.

Usage:
    python src/feature_engineering.py
"""

import pandas as pd
import os

CLEAN_PATH = os.path.join("data", "telco_churn_clean.csv")
FEATURED_PATH = os.path.join("data", "telco_churn_featured.csv")

SERVICE_COLUMNS = [
    "OnlineSecurity", "OnlineBackup", "DeviceProtection",
    "TechSupport", "StreamingTV", "StreamingMovies",
]


def add_tenure_bucket(df):
    bins = [-1, 12, 24, 48, 100]
    labels = ["New (0-1yr)", "1-2yr", "2-4yr", "Veteran (4yr+)"]
    df["tenure_bucket"] = pd.cut(df["tenure"], bins=bins, labels=labels)
    return df


def add_avg_monthly_spend(df):
    # avoid divide-by-zero for brand new customers (tenure == 0)
    safe_tenure = df["tenure"].replace(0, 1)
    df["avg_monthly_spend"] = (df["TotalCharges"] / safe_tenure).round(2)
    return df


def add_num_services(df):
    df["num_services"] = (df[SERVICE_COLUMNS] == "Yes").sum(axis=1)
    return df


def add_has_internet_addons(df):
    df["has_internet_addons"] = (df["num_services"] > 0).astype(int)
    return df


def add_high_value_flag(df):
    threshold = df["MonthlyCharges"].quantile(0.75)
    df["is_high_value"] = (df["MonthlyCharges"] >= threshold).astype(int)
    return df


def engineer_features(df):
    df = df.copy()
    df = add_tenure_bucket(df)
    df = add_avg_monthly_spend(df)
    df = add_num_services(df)
    df = add_has_internet_addons(df)
    df = add_high_value_flag(df)
    return df


def encode_categoricals(df):
    """One-hot encode all object/category columns except the target."""
    target = df["Churn"]
    features = df.drop(columns=["Churn"])
    features_encoded = pd.get_dummies(features, drop_first=True)
    features_encoded["Churn"] = target
    return features_encoded


if __name__ == "__main__":
    if not os.path.exists(CLEAN_PATH):
        raise FileNotFoundError(
            f"Couldn't find {CLEAN_PATH}. Run: python src/data_cleaning.py first."
        )

    df = pd.read_csv(CLEAN_PATH)
    df = engineer_features(df)

    print("New features added:")
    print(df[["tenure_bucket", "avg_monthly_spend", "num_services",
              "has_internet_addons", "is_high_value"]].head())

    df_encoded = encode_categoricals(df)
    df_encoded.to_csv(FEATURED_PATH, index=False)

    print(f"\nFinal feature matrix shape: {df_encoded.shape}")
    print(f"Saved model-ready dataset to {FEATURED_PATH}")
