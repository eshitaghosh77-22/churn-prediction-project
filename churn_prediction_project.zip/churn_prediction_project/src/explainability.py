"""
explainability.py
------------------
STEP 5: Explain WHY the model predicts churn using SHAP
(SHapley Additive exPlanations).

This is the part that makes your project stand out - instead of a black-box
"72% churn probability", you can show exactly which features pushed the
prediction up or down for a SPECIFIC customer.

Requires: pip install shap

Usage:
    python src/explainability.py
"""

import pandas as pd
import numpy as np
import joblib
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

try:
    import shap
except ImportError:
    raise ImportError(
        "shap is not installed. Run: pip install shap\n"
        "(shap works best with tree-based models like Random Forest, "
        "XGBoost, or GradientBoosting - not with scaled Logistic Regression.)"
    )

FEATURED_PATH = os.path.join("data", "telco_churn_featured.csv")
MODELS_DIR = os.path.join("outputs", "models")
PLOTS_DIR = os.path.join("outputs", "plots")


def load_model_bundle():
    path = os.path.join(MODELS_DIR, "best_model.pkl")
    if not os.path.exists(path):
        raise FileNotFoundError(f"Couldn't find {path}. Run: python src/train_models.py first.")
    return joblib.load(path)


def get_shap_explainer(model, model_name):
    """
    Tree-based models (Random Forest, XGBoost, GradientBoosting) get the fast
    TreeExplainer. Logistic Regression falls back to the general Explainer.
    """
    if model_name in ("Random Forest", "XGBoost", "GradientBoosting"):
        return shap.TreeExplainer(model)
    else:
        return shap.Explainer(model, feature_names=None)


if __name__ == "__main__":
    os.makedirs(PLOTS_DIR, exist_ok=True)

    bundle = load_model_bundle()
    model = bundle["model"]
    scaler = bundle["scaler"]
    feature_columns = bundle["feature_columns"]
    model_name = bundle["model_name"]

    print(f"Explaining model: {model_name}")

    df = pd.read_csv(FEATURED_PATH)
    X = df[feature_columns]

    # Use a sample for speed on larger datasets
    X_sample = X.sample(min(300, len(X)), random_state=42)
    X_input = scaler.transform(X_sample) if scaler is not None else X_sample

    explainer = get_shap_explainer(model, model_name)
    shap_values = explainer(X_input)

    # For binary classifiers, shap_values may have shape (n, features, 2) - take class 1
    values = shap_values.values
    if values.ndim == 3:
        values = values[:, :, 1]

    # 1. Global summary plot - which features matter most overall
    plt.figure()
    shap.summary_plot(values, X_sample, feature_names=feature_columns, show=False)
    plt.tight_layout()
    plt.savefig(os.path.join(PLOTS_DIR, "07_shap_summary.png"), dpi=150, bbox_inches="tight")
    plt.close()
    print(f"Saved global SHAP summary plot to {PLOTS_DIR}/07_shap_summary.png")

    # 2. Local explanation for ONE example customer (waterfall plot)
    idx = 0
    plt.figure()
    single_explanation = shap.Explanation(
        values=values[idx],
        base_values=(shap_values.base_values[idx, 1]
                     if np.ndim(shap_values.base_values) > 1
                     else shap_values.base_values[idx]),
        data=X_sample.iloc[idx].values,
        feature_names=feature_columns,
    )
    shap.plots.waterfall(single_explanation, show=False)
    plt.tight_layout()
    plt.savefig(os.path.join(PLOTS_DIR, "08_shap_waterfall_example.png"), dpi=150, bbox_inches="tight")
    plt.close()
    print(f"Saved example customer SHAP waterfall to {PLOTS_DIR}/08_shap_waterfall_example.png")

    print("\nUse these two plots in your report:")
    print("- Summary plot -> 'these are the top drivers of churn overall'")
    print("- Waterfall plot -> 'here's exactly why THIS customer is predicted to churn'")
