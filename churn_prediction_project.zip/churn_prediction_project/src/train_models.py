"""
train_models.py
----------------
STEP 4: Train multiple models and compare them properly.

Since churn datasets are imbalanced (more "No churn" than "Churn"), we look
at precision, recall, F1, and ROC-AUC - NOT just accuracy.

Models trained:
  1. Logistic Regression (simple baseline)
  2. Random Forest
  3. XGBoost (if installed) -- falls back to GradientBoosting otherwise

The best model (by ROC-AUC) is saved to outputs/models/best_model.pkl
along with the list of feature column names, for use in the Streamlit app.

Usage:
    python src/train_models.py
"""

import pandas as pd
import numpy as np
import os
import joblib

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.metrics import (
    classification_report, roc_auc_score, confusion_matrix,
    precision_score, recall_score, f1_score, accuracy_score,
)

try:
    from xgboost import XGBClassifier
    HAS_XGBOOST = True
except ImportError:
    HAS_XGBOOST = False

FEATURED_PATH = os.path.join("data", "telco_churn_featured.csv")
MODELS_DIR = os.path.join("outputs", "models")


def load_features():
    if not os.path.exists(FEATURED_PATH):
        raise FileNotFoundError(
            f"Couldn't find {FEATURED_PATH}. Run: python src/feature_engineering.py first."
        )
    return pd.read_csv(FEATURED_PATH)


def prepare_train_test(df):
    X = df.drop(columns=["Churn"])
    y = df["Churn"]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    return X_train, X_test, y_train, y_test


def evaluate_model(name, model, X_test, y_test, scaled=False, scaler=None):
    X_eval = scaler.transform(X_test) if scaled else X_test
    y_pred = model.predict(X_eval)
    y_prob = model.predict_proba(X_eval)[:, 1]

    metrics = {
        "model": name,
        "accuracy": accuracy_score(y_test, y_pred),
        "precision": precision_score(y_test, y_pred),
        "recall": recall_score(y_test, y_pred),
        "f1": f1_score(y_test, y_pred),
        "roc_auc": roc_auc_score(y_test, y_prob),
    }
    print(f"\n--- {name} ---")
    print(classification_report(y_test, y_pred, target_names=["No Churn", "Churn"]))
    print(f"ROC-AUC: {metrics['roc_auc']:.4f}")
    print("Confusion matrix:\n", confusion_matrix(y_test, y_pred))
    return metrics


def train_all_models(X_train, X_test, y_train, y_test):
    results = []
    fitted_models = {}

    # 1. Logistic Regression (needs scaled features)
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    log_reg = LogisticRegression(max_iter=1000, class_weight="balanced")
    log_reg.fit(X_train_scaled, y_train)
    results.append(evaluate_model("Logistic Regression", log_reg, X_test, y_test,
                                   scaled=True, scaler=scaler))
    fitted_models["Logistic Regression"] = (log_reg, scaler)

    # 2. Random Forest (no scaling needed)
    rf = RandomForestClassifier(n_estimators=200, max_depth=8,
                                 class_weight="balanced", random_state=42)
    rf.fit(X_train, y_train)
    results.append(evaluate_model("Random Forest", rf, X_test, y_test))
    fitted_models["Random Forest"] = (rf, None)

    # 3. XGBoost or GradientBoosting fallback
    if HAS_XGBOOST:
        scale_pos_weight = (y_train == 0).sum() / (y_train == 1).sum()
        xgb = XGBClassifier(
            n_estimators=200, max_depth=5, learning_rate=0.1,
            scale_pos_weight=scale_pos_weight, eval_metric="logloss",
            random_state=42,
        )
        xgb.fit(X_train, y_train)
        results.append(evaluate_model("XGBoost", xgb, X_test, y_test))
        fitted_models["XGBoost"] = (xgb, None)
    else:
        print("\n[Note] xgboost not installed - using GradientBoosting instead.")
        print("Install it with: pip install xgboost")
        gb = GradientBoostingClassifier(n_estimators=200, max_depth=4, random_state=42)
        gb.fit(X_train, y_train)
        results.append(evaluate_model("GradientBoosting", gb, X_test, y_test))
        fitted_models["GradientBoosting"] = (gb, None)

    return results, fitted_models


if __name__ == "__main__":
    os.makedirs(MODELS_DIR, exist_ok=True)

    df = load_features()
    X_train, X_test, y_train, y_test = prepare_train_test(df)

    results, fitted_models = train_all_models(X_train, X_test, y_train, y_test)

    comparison_df = pd.DataFrame(results).sort_values("roc_auc", ascending=False)
    print("\n=== Model comparison (sorted by ROC-AUC) ===")
    print(comparison_df.to_string(index=False))

    best_name = comparison_df.iloc[0]["model"]
    best_model, best_scaler = fitted_models[best_name]
    print(f"\nBest model: {best_name}")

    # Save best model + metadata needed by the Streamlit app
    joblib.dump({
        "model": best_model,
        "scaler": best_scaler,             # None unless Logistic Regression
        "feature_columns": list(X_train.columns),
        "model_name": best_name,
    }, os.path.join(MODELS_DIR, "best_model.pkl"))

    comparison_df.to_csv(os.path.join(MODELS_DIR, "model_comparison.csv"), index=False)
    print(f"\nSaved best model to {MODELS_DIR}/best_model.pkl")
    print(f"Saved comparison table to {MODELS_DIR}/model_comparison.csv")
