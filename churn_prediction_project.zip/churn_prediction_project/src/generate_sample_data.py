"""
generate_sample_data.py
------------------------
STEP 1 (helper): Generates a synthetic dataset that mirrors the structure
of the popular "Telco Customer Churn" dataset from Kaggle.

WHY THIS FILE EXISTS:
The real dataset can't be auto-downloaded from Kaggle (needs a Kaggle account
+ API key). So this script lets you run and test the ENTIRE pipeline right
away using fake-but-realistic data. Once you're ready for your real
submission, download the actual dataset and drop it in:

    data/telco_churn.csv

Get the real dataset here:
https://www.kaggle.com/datasets/blastchar/telco-customer-churn

Usage:
    python src/generate_sample_data.py
"""

import numpy as np
import pandas as pd
import os

np.random.seed(42)

N = 2000  # number of fake customers

def generate_data(n=N):
    customer_id = [f"C{str(i).zfill(5)}" for i in range(n)]
    gender = np.random.choice(["Male", "Female"], n)
    senior_citizen = np.random.choice([0, 1], n, p=[0.84, 0.16])
    partner = np.random.choice(["Yes", "No"], n)
    dependents = np.random.choice(["Yes", "No"], n, p=[0.3, 0.7])
    tenure = np.random.randint(0, 73, n)  # months, 0-72

    phone_service = np.random.choice(["Yes", "No"], n, p=[0.9, 0.1])
    multiple_lines = np.where(
        phone_service == "No", "No phone service",
        np.random.choice(["Yes", "No"], n)
    )
    internet_service = np.random.choice(
        ["DSL", "Fiber optic", "No"], n, p=[0.35, 0.45, 0.2]
    )

    def dependent_on_internet(col_yes_prob=0.5):
        return np.where(
            internet_service == "No", "No internet service",
            np.random.choice(["Yes", "No"], n, p=[col_yes_prob, 1 - col_yes_prob])
        )

    online_security = dependent_on_internet(0.35)
    online_backup = dependent_on_internet(0.4)
    device_protection = dependent_on_internet(0.4)
    tech_support = dependent_on_internet(0.35)
    streaming_tv = dependent_on_internet(0.45)
    streaming_movies = dependent_on_internet(0.45)

    contract = np.random.choice(
        ["Month-to-month", "One year", "Two year"], n, p=[0.55, 0.25, 0.2]
    )
    paperless_billing = np.random.choice(["Yes", "No"], n, p=[0.6, 0.4])
    payment_method = np.random.choice(
        ["Electronic check", "Mailed check", "Bank transfer (automatic)",
         "Credit card (automatic)"], n
    )

    # Monthly charges depend loosely on internet service + streaming add-ons
    base_charge = np.where(internet_service == "Fiber optic", 70,
                   np.where(internet_service == "DSL", 45, 20))
    addon_charge = (
        (streaming_tv == "Yes").astype(int) * 8
        + (streaming_movies == "Yes").astype(int) * 8
        + (online_security == "Yes").astype(int) * 5
        + (tech_support == "Yes").astype(int) * 5
    )
    monthly_charges = base_charge + addon_charge + np.random.normal(0, 5, n)
    monthly_charges = np.round(np.clip(monthly_charges, 18, 120), 2)

    total_charges = np.round(monthly_charges * tenure + np.random.normal(0, 20, n), 2)
    total_charges = np.clip(total_charges, 0, None)

    # Churn probability logic: short tenure + month-to-month + fiber + high charges -> higher churn
    churn_score = (
        (contract == "Month-to-month").astype(int) * 0.35
        + (tenure < 12).astype(int) * 0.30
        + (internet_service == "Fiber optic").astype(int) * 0.15
        + (monthly_charges > 80).astype(int) * 0.15
        + (tech_support == "No").astype(int) * 0.10
        - (contract == "Two year").astype(int) * 0.25
    )
    churn_prob = 1 / (1 + np.exp(-(churn_score * 5 - 2.5)))  # squash to 0-1
    churn = np.where(np.random.rand(n) < churn_prob, "Yes", "No")

    df = pd.DataFrame({
        "customerID": customer_id,
        "gender": gender,
        "SeniorCitizen": senior_citizen,
        "Partner": partner,
        "Dependents": dependents,
        "tenure": tenure,
        "PhoneService": phone_service,
        "MultipleLines": multiple_lines,
        "InternetService": internet_service,
        "OnlineSecurity": online_security,
        "OnlineBackup": online_backup,
        "DeviceProtection": device_protection,
        "TechSupport": tech_support,
        "StreamingTV": streaming_tv,
        "StreamingMovies": streaming_movies,
        "Contract": contract,
        "PaperlessBilling": paperless_billing,
        "PaymentMethod": payment_method,
        "MonthlyCharges": monthly_charges,
        "TotalCharges": total_charges,
        "Churn": churn,
    })

    # sprinkle a few blank TotalCharges strings, just like the real dataset has
    df["TotalCharges"] = df["TotalCharges"].astype(object)
    blank_idx = np.random.choice(df.index, size=5, replace=False)
    df.loc[blank_idx, "TotalCharges"] = " "

    return df


if __name__ == "__main__":
    df = generate_data()
    os.makedirs("data", exist_ok=True)
    out_path = os.path.join("data", "telco_churn.csv")
    df.to_csv(out_path, index=False)
    print(f"Synthetic dataset with {len(df)} rows saved to {out_path}")
    print("\nReplace this file with the real Kaggle dataset when ready:")
    print("https://www.kaggle.com/datasets/blastchar/telco-customer-churn")
