"""
eda.py
------
STEP 2: Exploratory Data Analysis.

Generates a set of plots that reveal WHY customers churn, and saves them
as PNG files in outputs/plots/. Use these directly in your project report
or presentation slides.

Usage:
    python src/eda.py
"""

import pandas as pd
import matplotlib
matplotlib.use("Agg")  # no GUI needed, just save files
import matplotlib.pyplot as plt
import seaborn as sns
import os

CLEAN_PATH = os.path.join("data", "telco_churn_clean.csv")
PLOTS_DIR = os.path.join("outputs", "plots")

sns.set_theme(style="whitegrid")


def load_clean_data():
    if not os.path.exists(CLEAN_PATH):
        raise FileNotFoundError(
            f"Couldn't find {CLEAN_PATH}. Run: python src/data_cleaning.py first."
        )
    return pd.read_csv(CLEAN_PATH)


def plot_churn_distribution(df):
    plt.figure(figsize=(5, 4))
    ax = sns.countplot(x="Churn", data=df, hue="Churn", palette="Set2", legend=False)
    ax.set_xticks([0, 1])
    ax.set_xticklabels(["No Churn", "Churn"])
    plt.title("Overall Churn Distribution")
    plt.ylabel("Number of Customers")
    plt.tight_layout()
    plt.savefig(os.path.join(PLOTS_DIR, "01_churn_distribution.png"), dpi=150)
    plt.close()


def plot_churn_by_contract(df):
    plt.figure(figsize=(6, 4))
    churn_rate = df.groupby("Contract")["Churn"].mean().sort_values(ascending=False)
    sns.barplot(x=churn_rate.index, y=churn_rate.values, hue=churn_rate.index, palette="Set2", legend=False)
    plt.title("Churn Rate by Contract Type")
    plt.ylabel("Churn Rate")
    plt.xticks(rotation=15)
    plt.tight_layout()
    plt.savefig(os.path.join(PLOTS_DIR, "02_churn_by_contract.png"), dpi=150)
    plt.close()


def plot_tenure_vs_churn(df):
    plt.figure(figsize=(6, 4))
    sns.histplot(data=df, x="tenure", hue="Churn", multiple="stack",
                 bins=24, palette="Set2")
    plt.title("Tenure Distribution by Churn")
    plt.xlabel("Tenure (months)")
    plt.tight_layout()
    plt.savefig(os.path.join(PLOTS_DIR, "03_tenure_vs_churn.png"), dpi=150)
    plt.close()


def plot_monthly_charges_vs_churn(df):
    plt.figure(figsize=(6, 4))
    sns.boxplot(x="Churn", y="MonthlyCharges", data=df, hue="Churn",
                palette="Set2", legend=False)
    plt.xticks([0, 1], ["No Churn", "Churn"])
    plt.title("Monthly Charges by Churn Status")
    plt.tight_layout()
    plt.savefig(os.path.join(PLOTS_DIR, "04_monthly_charges_vs_churn.png"), dpi=150)
    plt.close()


def plot_internet_service_churn(df):
    plt.figure(figsize=(6, 4))
    churn_rate = df.groupby("InternetService")["Churn"].mean().sort_values(ascending=False)
    sns.barplot(x=churn_rate.index, y=churn_rate.values, hue=churn_rate.index, palette="Set2", legend=False)
    plt.title("Churn Rate by Internet Service Type")
    plt.ylabel("Churn Rate")
    plt.tight_layout()
    plt.savefig(os.path.join(PLOTS_DIR, "05_churn_by_internet_service.png"), dpi=150)
    plt.close()


def plot_correlation_heatmap(df):
    plt.figure(figsize=(6, 5))
    numeric_df = df.select_dtypes(include="number")
    corr = numeric_df.corr()
    sns.heatmap(corr, annot=True, cmap="coolwarm", fmt=".2f")
    plt.title("Correlation Heatmap (Numeric Features)")
    plt.tight_layout()
    plt.savefig(os.path.join(PLOTS_DIR, "06_correlation_heatmap.png"), dpi=150)
    plt.close()


if __name__ == "__main__":
    os.makedirs(PLOTS_DIR, exist_ok=True)
    df = load_clean_data()

    plot_churn_distribution(df)
    plot_churn_by_contract(df)
    plot_tenure_vs_churn(df)
    plot_monthly_charges_vs_churn(df)
    plot_internet_service_churn(df)
    plot_correlation_heatmap(df)

    print(f"Saved 6 EDA plots to {PLOTS_DIR}/")
    print("\nKey findings to mention in your report:")
    print(f"- Month-to-month churn rate: {df[df.Contract=='Month-to-month']['Churn'].mean():.1%}")
    print(f"- Two year contract churn rate: {df[df.Contract=='Two year']['Churn'].mean():.1%}")
    print(f"- Avg tenure (churned): {df[df.Churn==1]['tenure'].mean():.1f} months")
    print(f"- Avg tenure (retained): {df[df.Churn==0]['tenure'].mean():.1f} months")
