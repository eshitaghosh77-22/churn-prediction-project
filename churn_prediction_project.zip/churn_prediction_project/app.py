"""
app.py
------
STEP 6: Interactive Streamlit dashboard.

Lets a user enter a customer's details in the sidebar and instantly see:
  - Predicted churn probability
  - A SHAP waterfall chart explaining WHY

Run with:
    streamlit run app.py

Requires the pipeline to have already been run once:
    python src/generate_sample_data.py   (or use the real dataset)
    python src/data_cleaning.py
    python src/feature_engineering.py
    python src/train_models.py
"""

import streamlit as st
import pandas as pd
import numpy as np
import joblib
import os
import matplotlib.pyplot as plt

st.set_page_config(page_title="Customer Churn Predictor", page_icon="📉", layout="wide")

MODELS_DIR = os.path.join("outputs", "models")
MODEL_PATH = os.path.join(MODELS_DIR, "best_model.pkl")


@st.cache_resource
def load_model_bundle():
    return joblib.load(MODEL_PATH)


def build_input_row(feature_columns, raw_inputs):
    """
    Turns the sidebar's raw inputs (in original, human-readable form) into
    a one-hot-encoded row matching the model's training columns.
    """
    row = pd.DataFrame([raw_inputs])

    # Re-create the same engineered features used in training
    row["avg_monthly_spend"] = round(
        raw_inputs["TotalCharges"] / max(raw_inputs["tenure"], 1), 2
    )
    service_cols = ["OnlineSecurity", "OnlineBackup", "DeviceProtection",
                     "TechSupport", "StreamingTV", "StreamingMovies"]
    row["num_services"] = sum(1 for c in service_cols if raw_inputs[c] == "Yes")
    row["has_internet_addons"] = int(row["num_services"].iloc[0] > 0)
    row["is_high_value"] = int(raw_inputs["MonthlyCharges"] >= 80)  # rough static cutoff for the demo

    tenure = raw_inputs["tenure"]
    if tenure <= 12:
        bucket = "New (0-1yr)"
    elif tenure <= 24:
        bucket = "1-2yr"
    elif tenure <= 48:
        bucket = "2-4yr"
    else:
        bucket = "Veteran (4yr+)"
    row["tenure_bucket"] = bucket

    row_encoded = pd.get_dummies(row)

    # Align to the exact columns the model was trained on
    for col in feature_columns:
        if col not in row_encoded.columns:
            row_encoded[col] = 0
    row_encoded = row_encoded[feature_columns]

    return row_encoded


def main():
    st.title("📉 Customer Churn Predictor")
    st.caption("Enter a customer's details in the sidebar to predict churn risk.")

    if not os.path.exists(MODEL_PATH):
        st.error(
            "No trained model found. Run the pipeline first:\n\n"
            "```\npython src/generate_sample_data.py\n"
            "python src/data_cleaning.py\n"
            "python src/feature_engineering.py\n"
            "python src/train_models.py\n```"
        )
        return

    bundle = load_model_bundle()
    model = bundle["model"]
    scaler = bundle["scaler"]
    feature_columns = bundle["feature_columns"]
    model_name = bundle["model_name"]

    st.sidebar.header("Customer details")
    tenure = st.sidebar.slider("Tenure (months)", 0, 72, 12)
    monthly_charges = st.sidebar.slider("Monthly Charges ($)", 18, 120, 70)
    total_charges = st.sidebar.number_input(
        "Total Charges ($)", min_value=0.0, value=float(tenure * monthly_charges)
    )
    contract = st.sidebar.selectbox("Contract", ["Month-to-month", "One year", "Two year"])
    internet_service = st.sidebar.selectbox("Internet Service", ["DSL", "Fiber optic", "No"])
    tech_support = st.sidebar.selectbox("Tech Support", ["Yes", "No", "No internet service"])
    online_security = st.sidebar.selectbox("Online Security", ["Yes", "No", "No internet service"])
    online_backup = st.sidebar.selectbox("Online Backup", ["Yes", "No", "No internet service"])
    device_protection = st.sidebar.selectbox("Device Protection", ["Yes", "No", "No internet service"])
    streaming_tv = st.sidebar.selectbox("Streaming TV", ["Yes", "No", "No internet service"])
    streaming_movies = st.sidebar.selectbox("Streaming Movies", ["Yes", "No", "No internet service"])
    payment_method = st.sidebar.selectbox("Payment Method", [
        "Electronic check", "Mailed check", "Bank transfer (automatic)", "Credit card (automatic)"
    ])
    paperless_billing = st.sidebar.selectbox("Paperless Billing", ["Yes", "No"])
    gender = st.sidebar.selectbox("Gender", ["Male", "Female"])
    senior_citizen = st.sidebar.selectbox("Senior Citizen", [0, 1])
    partner = st.sidebar.selectbox("Partner", ["Yes", "No"])
    dependents = st.sidebar.selectbox("Dependents", ["Yes", "No"])
    phone_service = st.sidebar.selectbox("Phone Service", ["Yes", "No"])
    multiple_lines = st.sidebar.selectbox("Multiple Lines", ["Yes", "No", "No phone service"])

    raw_inputs = {
        "gender": gender, "SeniorCitizen": senior_citizen, "Partner": partner,
        "Dependents": dependents, "tenure": tenure, "PhoneService": phone_service,
        "MultipleLines": multiple_lines, "InternetService": internet_service,
        "OnlineSecurity": online_security, "OnlineBackup": online_backup,
        "DeviceProtection": device_protection, "TechSupport": tech_support,
        "StreamingTV": streaming_tv, "StreamingMovies": streaming_movies,
        "Contract": contract, "PaperlessBilling": paperless_billing,
        "PaymentMethod": payment_method, "MonthlyCharges": monthly_charges,
        "TotalCharges": total_charges,
    }

    input_row = build_input_row(feature_columns, raw_inputs)
    model_input = scaler.transform(input_row) if scaler is not None else input_row

    churn_prob = model.predict_proba(model_input)[0][1]

    col1, col2 = st.columns([1, 2])
    with col1:
        st.metric("Churn Probability", f"{churn_prob:.1%}")
        if churn_prob >= 0.5:
            st.error(f"⚠️ High risk of churn (model: {model_name})")
        else:
            st.success(f"✅ Likely to stay (model: {model_name})")

    with col2:
        st.subheader("Why this prediction?")
        try:
            import shap
            explainer = (
                shap.TreeExplainer(model)
                if model_name in ("Random Forest", "XGBoost", "GradientBoosting")
                else shap.Explainer(model)
            )
            shap_values = explainer(model_input)
            values = shap_values.values
            if values.ndim == 3:
                values = values[:, :, 1]

            fig, ax = plt.subplots(figsize=(8, 5))
            single_explanation = shap.Explanation(
                values=values[0],
                base_values=(shap_values.base_values[0, 1]
                             if np.ndim(shap_values.base_values) > 1
                             else shap_values.base_values[0]),
                data=input_row.iloc[0].values,
                feature_names=feature_columns,
            )
            shap.plots.waterfall(single_explanation, show=False, max_display=8)
            st.pyplot(fig)
        except ImportError:
            st.info("Install `shap` (pip install shap) to see the explanation chart here.")

    st.divider()
    st.caption(
        "Note: this demo model was trained on synthetic data unless you swapped in "
        "the real Kaggle Telco Churn dataset. Predictions are illustrative."
    )


if __name__ == "__main__":
    main()
